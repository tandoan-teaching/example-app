-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: example_app
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `programming_languages`
--

DROP TABLE IF EXISTS `programming_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programming_languages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `released_year` int NOT NULL,
  `githut_rank` int DEFAULT NULL,
  `pypl_rank` int DEFAULT NULL,
  `tiobe_rank` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programming_languages`
--

LOCK TABLES `programming_languages` WRITE;
/*!40000 ALTER TABLE `programming_languages` DISABLE KEYS */;
INSERT INTO `programming_languages` VALUES (1,'JavaScript',1995,1,3,7,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(2,'Python',1991,2,1,3,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(3,'Java',1995,3,2,2,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(4,'TypeScript',2012,7,10,42,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(5,'C#',2000,9,4,5,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(6,'PHP',1995,8,6,8,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(7,'C++',1985,5,5,4,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(8,'C',1972,10,5,1,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(9,'Ruby',1995,6,15,15,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(10,'R',1993,33,7,9,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(11,'Objective-C',1984,18,8,18,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(12,'Swift',2015,16,9,13,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(13,'Kotlin',2011,15,12,40,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(14,'Go',2009,4,13,14,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(15,'Rust',2010,14,16,26,'2024-04-13 13:45:31','2024-04-13 13:45:31'),(16,'Scala',2004,11,17,34,'2024-04-13 13:45:31','2024-04-13 13:45:31');
/*!40000 ALTER TABLE `programming_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tutorials`
--

DROP TABLE IF EXISTS `tutorials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutorials` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type_id` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `published` tinyint(1) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutorials`
--

LOCK TABLES `tutorials` WRITE;
/*!40000 ALTER TABLE `tutorials` DISABLE KEYS */;
INSERT INTO `tutorials` VALUES (1,1,'React.js Intro Tut#1','Tut#1 Description',0,'2024-05-10 23:21:36','2024-05-10 23:21:36'),(2,1,'Node.js Express Tut#2','Tut#2 Description',0,'2024-05-10 23:21:36','2024-05-10 23:21:36'),(3,2,'React.js Node.js Express Tut#3','Tut#3 Description',0,'2024-05-10 23:21:36','2024-05-10 23:21:36'),(4,2,'React.js Advanced Tut#4','Tut#4 Description',0,'2024-05-10 23:21:36','2024-05-10 23:21:36'),(5,3,'Node.js Advanced Tut#5','Tut#5 Description',0,'2024-05-10 23:21:36','2024-05-10 23:21:36'),(6,3,'Node.js Advanced Tut#6','Tut#6 Description',NULL,'2024-05-11 07:28:27','2024-05-11 07:28:27'),(7,2,'Node.js Advanced Tut#7','Tut#7 Description',NULL,'2024-05-11 07:28:57','2024-05-11 07:28:57');
/*!40000 ALTER TABLE `tutorials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tutorials_type`
--

DROP TABLE IF EXISTS `tutorials_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tutorials_type` (
  `type_id` int NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updatedAt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tutorials_type`
--

LOCK TABLES `tutorials_type` WRITE;
/*!40000 ALTER TABLE `tutorials_type` DISABLE KEYS */;
INSERT INTO `tutorials_type` VALUES (1,'Type 1','Type 1 Description','2024-05-10 23:20:45','2024-05-10 23:20:45'),(2,'Type 2','Type 2 Description','2024-05-10 23:21:03','2024-05-10 23:21:03'),(3,'Type 3','Type 3 Description','2024-05-10 23:21:03','2024-05-10 23:21:03');
/*!40000 ALTER TABLE `tutorials_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-11  8:19:37
